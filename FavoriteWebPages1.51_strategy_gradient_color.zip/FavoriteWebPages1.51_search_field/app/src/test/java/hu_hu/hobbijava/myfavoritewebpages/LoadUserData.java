package hu_hu.hobbijava.myfavoritewebpages;

import android.content.Context;
import android.content.SharedPreferences;

import com.android_tanfolyam.myfavoritewebpages.R;

import hu_hu.hobbijava.myfavoritewebpages.controler.data.Constans;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class LoadUserData {

    private LoadUserData(){}

    private static SharedPreferences preferences;

    public static List<String> loadButtonText(Context c){

        List<String> result=new ArrayList<>();
        Set<String> defaultstringSet=new LinkedHashSet<>();

        preferences=c.getSharedPreferences
                (c.getString(R.string.shared_button_name)
                        ,Context.MODE_PRIVATE);

        if(preferences==null){

            for (int i = 0; i <Constans.getButtonCount() ; i++) {

                result.add("");


            }

            return  result;
        }

        for (int i = 0; i <Constans.getButtonCount() ; i++) {
            defaultstringSet.add(String.valueOf(i+1));
        }

        Set<String> stringSet = preferences.getStringSet(c.getString(R.string.shared_button_text), defaultstringSet);
        return  new ArrayList<>(stringSet);
    }

    public static List<String> loadFavoriteUrl(Context c){

        List<String> result=new ArrayList<>();
        Set<String> defaultstringSet=new LinkedHashSet<>();

        preferences=c.getSharedPreferences
                (c.getString(R.string.shared_web_url_name)
                        ,Context.MODE_PRIVATE);

        if(preferences==null){

            for (int i = 0; i <Constans.getButtonCount() ; i++) {

                result.add("");


            }

            return  result;
        }

        for (int i = 0; i <Constans.getButtonCount() ; i++) {
            defaultstringSet.add(String.valueOf(i));
        }

        Set<String> stringSet = preferences.getStringSet(c.getString(R.string.shared_web_url_text), defaultstringSet);
        return  new ArrayList<>(stringSet);
    }
}
