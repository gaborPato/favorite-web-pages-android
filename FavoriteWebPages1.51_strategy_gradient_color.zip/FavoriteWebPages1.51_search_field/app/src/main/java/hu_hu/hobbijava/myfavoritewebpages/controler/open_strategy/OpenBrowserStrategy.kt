package hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy

import android.graphics.Color

interface OpenBrowserStrategy {

    abstract fun getBackgrResource(): Int
   fun getExternalOpenBrowser():Boolean
}