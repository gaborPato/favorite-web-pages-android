package hu_hu.hobbijava.myfavoritewebpages.view.web_view

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import com.android_tanfolyam.myfavoritewebpages.R
import kotlinx.android.synthetic.main.activity_web_view.*

class WebViewActivity : AppCompatActivity() {

  private lateinit  var progressDialog: ProgressDialog
    private  lateinit var searchViewArray : ArrayList<View>

    companion object{

        private val supportedRunMimeType = arrayListOf("application/pdf")
        private  val googleSearch="https://www.google.com/search?q="

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_view)

        val passURL = intent.getStringExtra("url_pass")

         progressDialog = ProgressDialog(this)
        progressDialog.setMessage("load data......")
        progressDialog.setCancelable(false);
       web_view.webViewClient= AppWVClient()
        web_view.webChromeClient=ChromeClient(progressDialog)
        web_view.settings.javaScriptEnabled=true
        web_view.settings.loadsImagesAutomatically=true

        web_view.settings.builtInZoomControls=true

        web_view.settings.domStorageEnabled=true
        web_view.settings.setAppCacheEnabled(true)

        searchViewArray= arrayListOf<View>(search_button,search_editText)


        if (passURL != null){
            web_view.loadUrl(passURL)
        }


        search_ico.setOnClickListener(View.OnClickListener {
            searchViewArray.forEach { v ->
                if (v.visibility==View.GONE){
                    v.visibility= View.VISIBLE
                    search_ico.setImageResource(R.drawable.search_off)
                }else{
                    v.visibility=View.GONE
                    search_ico.setImageResource(R.drawable.search_on_ico)

                }
             }
        })
        search_button.setOnClickListener(View.OnClickListener {

            val query= search_editText.text.toString()
            if (query.length>0 && query != null){

                web_view.loadUrl("$googleSearch$query")
                val imm= this.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm?.toggleSoftInput(InputMethodManager.SHOW_FORCED,InputMethodManager.HIDE_NOT_ALWAYS)    }
                search_editText.setText("")
        })



        forward_imageButton.setOnClickListener(View.OnClickListener {
            if(web_view.canGoForward()){
                web_view.goForward()
            }
        })
        back_imageButton.setOnClickListener(View.OnClickListener {
            backPageAction()

        })
        home_button.setOnClickListener({
            web_view.loadUrl(passURL)
        })
        refresh_button.setOnClickListener({
            val actualUrl = web_view.url
            web_view.loadUrl(actualUrl)
        })
        close_btn_ico.setOnClickListener({

            closeWebViewProtocol()

        })
        web_view.setDownloadListener(DownloadListener {
            url, userAgent, contentDisposition, mimetype, contentLength ->

            Log.i("downloadMime", mimetype)
            if (supportedRunMimeType.contains(mimetype)){
                val i= Intent(Intent.ACTION_VIEW)
                i.setData(Uri.parse(url))
                startActivity(i)
            }

        })

    }

    private fun closeWebViewProtocol() {
        val dialog = ExitAlertDialog(this)
        dialog.setOnDismissListener {
            if(ExitAlertDialog.getExit()){
                super.onBackPressed()
            }
        }
        dialog.show()

    }

    private fun backPageAction():Boolean {

        if (web_view.canGoBack()){
            web_view.goBack()
            return true
        }
        return false


    }

    override fun onPause() {
        super.onPause()
        println("onPause")
        WebStorage.getInstance().deleteAllData()
    }


    override fun onBackPressed() {

        if(!backPageAction()){
         closeWebViewProtocol()
        }

    }

    class ChromeClient(pd:ProgressDialog) : WebChromeClient() {

        private var pd:ProgressDialog = pd

        override fun onProgressChanged(view: WebView?, newProgress: Int) {


            if (newProgress < 100) {
                pd.show();
            }
            if (newProgress == 100) {
                pd.dismiss();
            }

        }
    }


    class AppWVClient : WebViewClient() {

        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
            view?.loadUrl(url);
            return true;
        }


    }



}


