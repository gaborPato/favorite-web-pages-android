package hu_hu.hobbijava.myfavoritewebpages.controler

import android.graphics.Point
import android.view.Display

object CalculateTools {
    @JvmStatic
    fun buttonCountCalculate(defaultDisplay: Display): Int {
        val size=Point()
        defaultDisplay.getSize(size)
        var count=(size.y/100)
        if(size.y>2000){
            count=(size.y/100*.55).toInt()

    } else if (size.y>1600){
            count= (size.y/100*.7) .toInt()

        }else if (size.y>1100){
            count=(size.y/100*.9).toInt()
        }
        val m = "weight : " + size.y
        println(m)


        return count
    }


}