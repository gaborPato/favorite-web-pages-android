package hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy

import com.android_tanfolyam.myfavoritewebpages.R

class InternalBrowserStrategy : OpenBrowserStrategy {
    override fun getExternalOpenBrowser(): Boolean {
        return false
    }


    override fun getBackgrResource(): Int {


        return R.drawable.web_view_gradient_resize
    }


}