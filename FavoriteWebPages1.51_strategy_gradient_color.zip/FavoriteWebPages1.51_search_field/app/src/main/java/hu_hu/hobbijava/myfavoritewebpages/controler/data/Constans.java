package hu_hu.hobbijava.myfavoritewebpages.controler.data;

public class Constans {

    private static int buttonCount=6;

    public static int getButtonCount() {
        return buttonCount;
    }
}
