package hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy;

import com.android_tanfolyam.myfavoritewebpages.R;

import hu_hu.hobbijava.myfavoritewebpages.view.MainActivity;

public final class ExternalBrowserStrategy implements OpenBrowserStrategy {
    @Override
    public int getBackgrResource() {

        int chrome_gradient = R.drawable.chrome_gradient_resize;
        return chrome_gradient;
    }

    @Override
    public boolean getExternalOpenBrowser() {
        return true;
    }
}
