package hu_hu.hobbijava.myfavoritewebpages.controler.data.dataManeger

import android.content.Context
import android.content.SharedPreferences
import com.android_tanfolyam.myfavoritewebpages.R

import hu_hu.hobbijava.myfavoritewebpages.view.MainActivity
import java.util.*


object LoadData {

    private var preferences: SharedPreferences? = null
    private var btnC=MainActivity.getButtonCount()

    @JvmStatic
    fun loadButtonText(c: Context): MutableList<String> {

        val result = ArrayList<String>()


        preferences = c.getSharedPreferences(c.getString(R.string.shared_button_name), Context.MODE_PRIVATE)

        if (preferences == null) {

            for (i in 0 until btnC) {

                result.add("")


            }

            return result
        }

        for (i in 0 until btnC) {
            result.add(preferences?.getString
            (c.getString(R.string.shared_button_text) + i.toString(), "") as String)
        }


        return result
    }

    @JvmStatic
    fun loadFavoriteUrl(c: Context): MutableList<String> {
        val result = ArrayList<String>()


        preferences = c.getSharedPreferences(c.getString(R.string.shared_web_url_name), Context.MODE_PRIVATE)

        if (preferences == null) {

            for (i in 0 until btnC) {

                result.add("")


            }

            return result
        }

        for (i in 0 until btnC) {
            result.add(preferences?.getString
            (c.getString(R.string.shared_web_url_text) + i.toString(), "") as String)
        }


        return result
    }

    @JvmStatic
    fun loadExternalOpen(c: Context): MutableList<Boolean> {

        val result= ArrayList<Boolean>()

        preferences = c.getSharedPreferences(c.getString(R.string.shared_ext_open_name), Context.MODE_PRIVATE)

        if (preferences==null){
            for (i in 0 until  btnC){
                result.add(false)
            }
            return  result
        }else{
            for (i in 0 until  btnC){
                result.add(preferences?.getBoolean
                (c.getString(R.string.shared_ext_open_bool) + i.toString(), false) as Boolean );
            }
            return result
        }



    }

}