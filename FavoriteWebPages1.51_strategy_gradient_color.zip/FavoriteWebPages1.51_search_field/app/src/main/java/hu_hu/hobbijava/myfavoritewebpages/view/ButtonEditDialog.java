package hu_hu.hobbijava.myfavoritewebpages.view;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.text.InputType;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import com.android_tanfolyam.myfavoritewebpages.R;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.EmptyButtonStrategy;
import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.ExternalBrowserStrategy;
import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.InternalBrowserStrategy;


class ButtonEditDialog extends AlertDialog.Builder {
    public ButtonEditDialog(@NonNull Context context, final MainActivity.UserButton userButton) {
        super(context);
        final AtomicInteger whichButton= new AtomicInteger();
        final AtomicBoolean externalOpen = new AtomicBoolean();
        externalOpen.set(userButton.isExternalOpen());

        LinearLayout multilineTextLayout = new LinearLayout(context);
        multilineTextLayout.setOrientation(LinearLayout.VERTICAL);

         final EditText inputButtonCoverText = new EditText(context);
         final EditText inputWebAddressText = new EditText(context);
         CheckBox externalOpenCheckBox= new CheckBox(context);

        externalOpenCheckBox.setText("open in external browser");
        externalOpenCheckBox.setTextColor(Color.RED);
        externalOpenCheckBox.setChecked(externalOpen.get());
        externalOpenCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                externalOpen.set(isChecked);

            }
        });

        inputButtonCoverText.setText(userButton.getText());
        inputWebAddressText.setText(userButton.getUserFavoriteUrl());
        inputButtonCoverText.setHint(R.string.input_button_text_hint);
        inputWebAddressText.setHint(R.string.input_webpages_text_hint);
        inputButtonCoverText.setInputType(InputType.TYPE_CLASS_TEXT);
        inputWebAddressText.setInputType(InputType.TYPE_CLASS_TEXT);
        multilineTextLayout.addView(inputButtonCoverText);
        multilineTextLayout.addView(inputWebAddressText);
        multilineTextLayout.addView(externalOpenCheckBox);


     //   android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
        this.setTitle(R.string.dialog_title);

        this.setView(multilineTextLayout);

        this.setCancelable(false);

        this.setNeutralButton("empty button", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                whichButton.set(which);
                dialog.dismiss();

            }
        });

        this.setPositiveButton(R.string.positive_bt_text, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {


                whichButton.set(which);

                dialog.dismiss();
            }
        });

        this.setNegativeButton(R.string.negative_bt_text, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.cancel();

            }
        });


         this.create();
        this.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {

                switch (whichButton.get()){
                    case -1:
                        String buttonTextDialog, favUrlDialog;
                        buttonTextDialog = inputButtonCoverText.getText().toString();
                        favUrlDialog = inputWebAddressText.getText().toString();

                        userButton.setButtonText(buttonTextDialog);
                        userButton.setUserFavoriteUrlForEdit(favUrlDialog);

                        userButton.setBrowserStrategy(externalOpen.get() ? new ExternalBrowserStrategy() : new InternalBrowserStrategy());
                        break;
                    case -3:
                        userButton.setBrowserStrategy(new EmptyButtonStrategy());
                        userButton.letEmptyButton();
                        break;

                        default:
                            break;
                }
                ;
            }
        });

        this.show();

    }
}
