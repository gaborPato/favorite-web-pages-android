package hu_hu.hobbijava.myfavoritewebpages.view;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Debug;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android_tanfolyam.myfavoritewebpages.R;

import java.util.ArrayList;
import java.util.List;

import hu_hu.hobbijava.myfavoritewebpages.controler.CalculateTools;
import hu_hu.hobbijava.myfavoritewebpages.controler.CheckTools;
import hu_hu.hobbijava.myfavoritewebpages.controler.data.dataManeger.LoadData;
import hu_hu.hobbijava.myfavoritewebpages.controler.data.dataManeger.SaveData;
import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.EmptyButtonStrategy;
import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.ExternalBrowserStrategy;
import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.InternalBrowserStrategy;
import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.OpenBrowserStrategy;
import hu_hu.hobbijava.myfavoritewebpages.view.web_view.WebViewActivity;


public class MainActivity extends AppCompatActivity
        implements View.OnClickListener, View.OnLongClickListener {

    private static int buttonCount;

    public static int getButtonCount() {
        return buttonCount;
    }

    private UserButton[] userButtons;
    private LinearLayout buttonsLinearLayout;
    private Intent intentURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

     /*   ActivityManager actManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memInfo = new ActivityManager.MemoryInfo();
        actManager.getMemoryInfo(memInfo);
        long totalMemory = memInfo.totalMem;
        System.out.println("Total mem: "+totalMemory/(1024*1024));*/


        buttonCount = calculateButtonCount();
        initUserButtons();

//A gombokat itt kódbol adom hozzá az activityhez
        buttonsLinearLayout = findViewById(R.id.Button_Array_root_linear_layout);

        for (Button userButton : userButtons)
            buttonsLinearLayout.addView(userButton);
    }

    private int calculateButtonCount() {

        Display defaultDisplay = getWindowManager().getDefaultDisplay();
        return CalculateTools.buttonCountCalculate(defaultDisplay);
    }

    private void initUserButtons() {


        int height=(int)( getResources().getDisplayMetrics().density*50);
        System.out.println("Height :  " + height);
        LinearLayout.LayoutParams params= new LinearLayout.LayoutParams
                (ViewGroup.LayoutParams.MATCH_PARENT,height);
        params.setMargins(20,6,20,6);

        List<String> userButtonText = LoadData.loadButtonText(getApplicationContext());
        List<String> userFavoriteUrl = LoadData.loadFavoriteUrl(getApplicationContext());
        List<Boolean> externalOpen = LoadData.loadExternalOpen(getApplicationContext());
        userButtons = new UserButton[buttonCount];

        for (int index = 0; index < userButtons.length; index++) {
          OpenBrowserStrategy strategy=  createStrategy_forStartApp(index,userButtonText,externalOpen);

            userButtons[index] = new UserButton(this);
            userButtons[index].setId(R.id.Button_Array_root_linear_layout + index);
            userButtons[index].setOnClickListener(this);
            userButtons[index].setOnLongClickListener(this);
            userButtons[index].setText(userButtonText.get(index) == null ? "" : userButtonText.get(index));
            userButtons[index].initFavoritURLforAppStart(userFavoriteUrl.get(index) == null ? "" : userFavoriteUrl.get(index));
            userButtons[index].setTextSize(19.2f);
            userButtons[index].setHint("press long to edit");
            userButtons[index].setBrowserStrategy(strategy);
            userButtons[index].setLayoutParams(params);


        }

    }

    private OpenBrowserStrategy createStrategy_forStartApp(int index, List<String> userButtonText, List<Boolean> externalOpen) {

        OpenBrowserStrategy resultStrategy= new InternalBrowserStrategy();
        if(externalOpen.get(index) != null &&externalOpen.get(index)) {resultStrategy= new ExternalBrowserStrategy();}
        if(userButtonText.get(index)==null || userButtonText.get(index).equals("")){
            resultStrategy= new EmptyButtonStrategy();
        }
        return resultStrategy;
    }

    @Override
    public void onClick(View v) {

        if (!CheckTools.INSTANCE.checkNetwork(this)) {
            final AlertDialog noConnectionDialog = NoConnectionDialog.getNoConnectionDialog(this);

            noConnectionDialog.show();

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    noConnectionDialog.cancel();
                }
            }, 2600);

            return;
        }
        for (int i = 0; i < userButtons.length; i++) {

            if (v.getId() == R.id.Button_Array_root_linear_layout + i) {

                String url = userButtons[i].getUserFavoriteUrl();
                if (!url.equals("") && url != null) {

                    if (userButtons[i].isExternalOpen()) {
                        intentURL = new Intent(Intent.ACTION_VIEW);
                        intentURL.setData(Uri.parse(url));
                    } else {
                        intentURL = new Intent(this, WebViewActivity.class);
                        intentURL.putExtra("url_pass", url);
                    }
                    startActivity(intentURL);
                } else {
                    Toast.makeText(getApplicationContext(),
                            "Blank address, long press to edit", Toast.LENGTH_LONG).show();
                }

            }
        }


    }

    @Override
    public boolean onLongClick(View v) {

        for (int position = 0; position < userButtons.length; position++) {

            if (v.getId() == R.id.Button_Array_root_linear_layout + position) {

                new ButtonEditDialog(this, userButtons[position]);
            }

        }
        return true;
    }


    @Override
    protected void onPause() {
        super.onPause();


        List<String> userButtonText = new ArrayList<>();
        List<String> userFavoriteUrl = new ArrayList<>();
        List<Boolean> externalOpen = new ArrayList<>();

        for (int i = 0; i < userButtons.length; i++) {
            userButtonText.add(userButtons[i].getText().toString());
            userFavoriteUrl.add(userButtons[i].getUserFavoriteUrl());
            externalOpen.add(userButtons[i].isExternalOpen());
        }
        SaveData.INSTANCE.buttonTextSave(getApplicationContext(), userButtonText);
        SaveData.INSTANCE.webSiteAddressTextSave(getApplicationContext(), userFavoriteUrl);
        SaveData.INSTANCE.externalOpenStatusSave(getApplicationContext(), externalOpen);
    }


    @Override
    protected void onStop() {
        super.onStop();
    }


    class UserButton extends androidx.appcompat.widget.AppCompatButton {

        private boolean externalOpen;
        private String userFavoriteUrl;

         void setBrowserStrategy(OpenBrowserStrategy browserStrategy) {
            this.colorStrategy = browserStrategy;

            this.externalOpen=browserStrategy.getExternalOpenBrowser();
             this.setBackgroundResource(browserStrategy.getBackgrResource());

            
        }

        private OpenBrowserStrategy colorStrategy;


        UserButton(Context context) {
            super(context);
            userFavoriteUrl = "";

        }


        boolean isExternalOpen() {
            return externalOpen;
        }



        String getUserFavoriteUrl() {
            return userFavoriteUrl;
        }

        void setUserFavoriteUrlForEdit(String userFavoriteUrl) {

            try {
                CheckTools.INSTANCE.checkButtonUrlEdit(userFavoriteUrl);
                this.userFavoriteUrl = userFavoriteUrl;
            } catch (Exception e) {

                Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();

                new ButtonEditDialog(MainActivity.this, this);
            }
        }

        void setButtonText(String text) {
            if (text.equals("")) {
                this.setText("no title");
            } else {
                this.setText(text);
            }
        }

        private void initFavoritURLforAppStart(String starturl) {
            this.userFavoriteUrl = starturl;
        }

         void letEmptyButton() {
            this.userFavoriteUrl="";
            this.setText("");


        }
    }
}