package hu_hu.hobbijava.myfavoritewebpages.view;

import android.app.AlertDialog;
import android.content.Context;

import com.android_tanfolyam.myfavoritewebpages.R;

final class NoConnectionDialog {

    private NoConnectionDialog(){}

   static AlertDialog getNoConnectionDialog(Context context){
        AlertDialog.Builder builder= new AlertDialog.Builder(context)
                .setTitle("error")
                .setIcon(R.drawable.no_internet_icon)

                .setMessage("No connection to internet")
                .setCancelable(false);


        return builder.create();
    }
}
