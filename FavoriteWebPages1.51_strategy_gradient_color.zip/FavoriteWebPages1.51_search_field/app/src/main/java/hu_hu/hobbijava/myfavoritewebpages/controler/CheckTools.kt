package hu_hu.hobbijava.myfavoritewebpages.controler

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkInfo
import android.os.Build
import hu_hu.hobbijava.myfavoritewebpages.controler.exceptions.EmptyUrlException
import hu_hu.hobbijava.myfavoritewebpages.controler.exceptions.InvalidUrlException
import java.util.*

object CheckTools {

    fun checkNetwork(context: Context):Boolean{

        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val activeNetwork = connectivityManager.activeNetwork
           if (activeNetwork== null) {return false}
            val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)

            return (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))



        } else {
            //TODO("VERSION.SDK_INT < M")
            return (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED
                    || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED)
        }
    }

    fun checkButtonUrlEdit(favUrlDialog: String){

        if (favUrlDialog.equals("")){
            throw EmptyUrlException()
        }

        val validURL: MutableList<String> = ArrayList()
        validURL.add("http://")
        validURL.add("https://")
        validURL.add("ftp://")
        validURL.add("ftps://")

        validURL.forEach {
            if (favUrlDialog.startsWith(it)){
                return
            }
        }

        throw InvalidUrlException()

    }
}