package hu_hu.hobbijava.myfavoritewebpages.controler.Address;


import hu_hu.hobbijava.myfavoritewebpages.controler.tools.CheckTools;

public final class WVUserAddress extends AddressWeb {
    private final String google_search_address = "https://www.google.com/search?q=";

    public WVUserAddress(String userQuery) {


        super(userQuery);

        url = CheckTools.INSTANCE.clearAndMakeHTTPUrl(userQuery);

        if (!CheckTools.INSTANCE.urlValidator(url)) {
            url = google_search_address + userQuery;

        }
    }
}
