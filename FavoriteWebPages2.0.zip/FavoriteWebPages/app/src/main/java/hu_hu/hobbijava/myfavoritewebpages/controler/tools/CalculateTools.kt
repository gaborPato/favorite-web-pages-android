package hu_hu.hobbijava.myfavoritewebpages.controler.tools

import android.graphics.Point
import android.view.Display
import kotlin.math.roundToInt

object CalculateTools {
    @JvmStatic
    fun buttonCountCalculate(defaultDisplay: Display): Int {
        val size = Point()
        defaultDisplay.getSize(size)
        var count = 10
        if (size.y > 2000) {
            count =30

        } else if (size.y > 1600) {
            count = 25

        } else if (size.y > 1100) {
            count =18
        }
        val m = "weight : " + size.y
        println(m)


        return count*1.5.toInt()
    }

    fun checkX_Size(defaultDisplay: Display): Int {

        val size = Point()
        defaultDisplay.getSize(size)


        return size.x
    }

    fun createCoverFromUrl(url: String): String {

        var result= url
        result=result.substringAfter(delimiter = "://")
        result= result.substringAfter("www.")
        result= result.substringAfter("m.")
        result=result.substringBefore(".")
        return result
    }


}