package hu_hu.hobbijava.myfavoritewebpages.view.web_view

import android.content.Context
import com.android_tanfolyam.myfavoritewebpages.R

class ExitAlertDialog(context: Context) : android.app.AlertDialog.Builder(context) {
    companion object {
        private var exit: Boolean? = null

        fun getExit(): Boolean {
            return exit as Boolean
        }
    }

    init {
        exit = false

        this.setTitle(" ")
        this.setIcon(R.drawable.exit_icon)
        this.setMessage("Confirm to exit from browser")
        this.setCancelable(false)
        this.setPositiveButton("yes") { dialog, which ->


            if (which == -1) {
                println(which)
                //WebViewActivity.exitAnswer = true
                exit = true
                dialog.dismiss()
            }
        }
        this.setNegativeButton("no") { dialog, which ->
            if (which != -1) {

                dialog.cancel()
            }
        }




        this.create()
    }
}