package hu_hu.hobbijava.myfavoritewebpages.view;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android_tanfolyam.myfavoritewebpages.R;

import java.util.ArrayList;
import java.util.List;

import hu_hu.hobbijava.myfavoritewebpages.controler.Address.AddressWeb;
import hu_hu.hobbijava.myfavoritewebpages.controler.Address.ButtonWebAddress;
import hu_hu.hobbijava.myfavoritewebpages.controler.Address.WVUserAddress;
import hu_hu.hobbijava.myfavoritewebpages.controler.data.AllowedBookMark;
import hu_hu.hobbijava.myfavoritewebpages.controler.data.CustomToastColor;
import hu_hu.hobbijava.myfavoritewebpages.controler.data.dataManeger.LoadData;
import hu_hu.hobbijava.myfavoritewebpages.controler.data.dataManeger.SaveData;
import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.EmptyButtonStrategy;
import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.ExternalBrowserStrategy;
import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.InternalBrowserStrategy;
import hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.OpenBrowserStrategy;
import hu_hu.hobbijava.myfavoritewebpages.controler.tools.CalculateTools;
import hu_hu.hobbijava.myfavoritewebpages.controler.tools.CheckTools;
import hu_hu.hobbijava.myfavoritewebpages.view.web_view.WebViewActivity;


public class MainActivity extends AppCompatActivity
        implements View.OnClickListener, View.OnLongClickListener {

    private static int buttonCount;

    public static int getButtonCount() {
        return buttonCount;
    }

    private UserButton[] userButtons;
    private LinearLayout buttonsLinearLayout;
    private Intent intentURL;
    private int apiLevel;
    private EditText searchEditText;
    private Button searchButton;


    private static List<AllowedBookMark> allowedBookMark;

    public static List<AllowedBookMark> getAllowedBookMark() {
        return allowedBookMark;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        setClickableViews(true);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        apiLevel = Build.VERSION.SDK_INT;

        searchButton = findViewById(R.id.search_button_for_main_act);
        searchButton.setEnabled(true);


        initSearchEditText();

        buttonCount = calculateButtonCount();
        initUserButtons();

        addViewToLayout();


    }

    private void initAllowedBookmark() {
        allowedBookMark = new ArrayList<>();
        for (UserButton userButton : userButtons) {
            if (userButton.strategy instanceof InternalBrowserStrategy || userButton.strategy instanceof ExternalBrowserStrategy) {
                allowedBookMark.add(new AllowedBookMark(userButton.getText().toString(), userButton.getUserFavoriteUrl(), userButton.externalOpen));
            }
        }
    }

    private void initSearchEditText() {
        searchEditText = findViewById(R.id.search_edit_text_for_main_act);


        //         InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        //      imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,InputMethodManager.HIDE_NOT_ALWAYS);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);


    }

    private void addViewToLayout() {
        buttonsLinearLayout = findViewById(R.id.Button_Array_root_linear_layout);

        if (apiLevel < 23) {
            TextView versionProblem_TV = findViewById(R.id.version_too_less_info);
            versionProblem_TV.setVisibility(View.VISIBLE);
        }
        for (Button userButton : userButtons)
            buttonsLinearLayout.addView(userButton);
    }

    private int calculateButtonCount() {

        Display defaultDisplay = getWindowManager().getDefaultDisplay();
        return CalculateTools.buttonCountCalculate(defaultDisplay);
    }

    private void initUserButtons() {


        int height = (int) (getResources().getDisplayMetrics().density * 50);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams
                (ViewGroup.LayoutParams.MATCH_PARENT, height);
        params.setMargins(20, 6, 20, 6);

        List<String> userButtonText = LoadData.loadButtonText(getApplicationContext());
        List<String> userFavoriteUrl = LoadData.loadFavoriteUrl(getApplicationContext());
        List<Boolean> externalOpen = LoadData.loadExternalOpen(getApplicationContext());
        userButtons = new UserButton[buttonCount];

        for (int index = 0; index < userButtons.length; index++) {
            OpenBrowserStrategy strategy = createStrategy_forStartApp(index, userButtonText, externalOpen);

            userButtons[index] = new UserButton(this);
            userButtons[index].setId(R.id.Button_Array_root_linear_layout + index);
            userButtons[index].setOnClickListener(this);
            userButtons[index].setOnLongClickListener(this);
            userButtons[index].setText(userButtonText.get(index) == null ? "" : userButtonText.get(index));
            userButtons[index].initFavoritURLforAppStart(userFavoriteUrl.get(index) == null ? "" : userFavoriteUrl.get(index));
            userButtons[index].setTextSize(19.2f);
            userButtons[index].setHint("press long to edit");
            userButtons[index].setBrowserStrategy(strategy);
            userButtons[index].setLayoutParams(params);


        }

    }

    private OpenBrowserStrategy createStrategy_forStartApp(int index, List<String> userButtonText, List<Boolean> externalOpen) {

        OpenBrowserStrategy resultStrategy = new InternalBrowserStrategy();
        if (externalOpen.get(index) != null && externalOpen.get(index)) {
            resultStrategy = new ExternalBrowserStrategy();
        }
        if (userButtonText.get(index) == null || userButtonText.get(index).equals("")) {
            resultStrategy = new EmptyButtonStrategy();
        }
        if (resultStrategy instanceof InternalBrowserStrategy && apiLevel < 23) {
            resultStrategy = new ExternalBrowserStrategy();
        }
        return resultStrategy;
    }

    @Override
    public void onClick(View v) {


        if (!CheckTools.INSTANCE.checkNetwork(this)) {

            final AlertDialog noConnectionDialog = NoConnectionDialog.getNoConnectionDialog(this);

            noConnectionDialog.show();

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    noConnectionDialog.cancel();
                }
            }, 2600);

            return;
        }
        setClickableViews(false);
        initAllowedBookmark();

        if (v.getId() == searchButton.getId() && searchEditText.getText().toString().length() > 1) {


            AddressWeb query = new WVUserAddress(searchEditText.getText().toString());
            if (apiLevel < 23) {
                openExternalBrowser(query.getUrl());

            } else {
                openInternalBrowser(query.getUrl());


            }
            startActivity(intentURL);
            return;
        }


        for (int i = 0; i < userButtons.length; i++) {
            if (v.getId() == R.id.Button_Array_root_linear_layout + i) {
                if (userButtons[i].strategy instanceof EmptyButtonStrategy) {
                    setClickableViews(true);
                    CustomToast.show(this, " Blank Address,long press to edit ", CustomToastColor.INSTANCE.getInfoNotifyColor());
                    return;
                }

                String url = userButtons[i].getUserFavoriteUrl();
                if (userButtons[i].isExternalOpen()) {
                    openExternalBrowser(url);

                } else {
                    openInternalBrowser(url);
                }

            }
        }


    }

    private void openInternalBrowser(String url) {
        intentURL = new Intent(this, WebViewActivity.class);
        intentURL.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intentURL.putExtra(getString(R.string.pass_url), new String[]{url, getString(R.string.normal_page_flag)});
        intentURL.putExtra("counter", 1);
        startActivity(intentURL);
    }

    private void openExternalBrowser(String url) {
        intentURL = new Intent(Intent.ACTION_VIEW);
        intentURL.setData(Uri.parse(url));
        startActivity(intentURL);
    }

    private void setClickableViews(boolean b) {
        searchButton.setEnabled(b);
        for (UserButton userButton : userButtons) {
            userButton.setEnabled(b);
        }
    }

    @Override
    public boolean onLongClick(View v) {

        for (int position = 0; position < userButtons.length; position++) {

            if (v.getId() == R.id.Button_Array_root_linear_layout + position) {

                new ButtonEditDialog(this, userButtons[position]);
            }

        }
        return true;
    }


    @Override
    protected void onPause() {
        super.onPause();


        List<String> userButtonText = new ArrayList<>();
        List<String> userFavoriteUrl = new ArrayList<>();
        List<Boolean> externalOpen = new ArrayList<>();

        for (int i = 0; i < userButtons.length; i++) {
            userButtonText.add(userButtons[i].getText().toString());
            userFavoriteUrl.add(userButtons[i].getUserFavoriteUrl());
            externalOpen.add(userButtons[i].isExternalOpen());
        }
        SaveData.INSTANCE.buttonTextSave(getApplicationContext(), userButtonText);
        SaveData.INSTANCE.webSiteAddressTextSave(getApplicationContext(), userFavoriteUrl);
        SaveData.INSTANCE.externalOpenStatusSave(getApplicationContext(), externalOpen);
    }


    public void saveClick(View view) {
        String clipBoardItemText = "";
        // AddressWeb buttonAddressWeb= null;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard.hasPrimaryClip()) {
            ClipData.Item clipBoardItem = clipboard.getPrimaryClip().getItemAt(0);
            clipBoardItemText = clipBoardItem.getText().toString();

            try {
                new ButtonWebAddress(clipBoardItemText);

            } catch (Exception r) {
                CustomToast.show(this, r.getMessage(), CustomToastColor.INSTANCE.getErrorNotifyColor());
                return;
            }
        }
        int ind = 0;
        for (; ind < userButtons.length; ind++) {
            if (userButtons[ind].strategy instanceof EmptyButtonStrategy) {

                userButtons[ind].userFavoriteUrl = clipBoardItemText;
                String buttonCover = CalculateTools.INSTANCE.createCoverFromUrl(clipBoardItemText);
                userButtons[ind].setButtonText(buttonCover);
                new ButtonEditDialog(this, userButtons[ind]);
                break;
            }


        }
        if (ind == userButtons.length) {
            CustomToast.show(this, "No more blank Buttons", CustomToastColor.INSTANCE.getInfoNotifyColor());
        }


    }


    class UserButton extends androidx.appcompat.widget.AppCompatButton {


        private boolean externalOpen;
        private String userFavoriteUrl;
        private OpenBrowserStrategy strategy;
        private AddressWeb buttonAddress;

        void setBrowserStrategy(OpenBrowserStrategy browserStrategy) {
            this.strategy = browserStrategy;
            if (apiLevel < 23) {
                if (strategy instanceof InternalBrowserStrategy) {
                    this.strategy = new ExternalBrowserStrategy();
                }
            }

            this.externalOpen = strategy.getExternalOpenBrowser();
            this.setBackgroundResource(strategy.getBackgrResource());


        }


        UserButton(Context context) {
            super(context);
            userFavoriteUrl = "";

        }

        @Override
        public void setText(CharSequence text, BufferType type) {
            String t = text.toString();
            t = t.toUpperCase();
            super.setText(t, type);
        }

        boolean isExternalOpen() {
            return externalOpen;
        }


        String getUserFavoriteUrl() {
            return userFavoriteUrl;
        }

        void setUserFavoriteUrlForEdit(String userFavoriteUrl) {

            try {
                buttonAddress = new ButtonWebAddress(userFavoriteUrl);
                this.userFavoriteUrl = buttonAddress.getUrl();


            } catch (Exception e) {

                CustomToast.show(MainActivity.this, e.getMessage(), CustomToastColor.INSTANCE.getErrorNotifyColor());


                new ButtonEditDialog(MainActivity.this, this);
            }
        }

        void setButtonText(String text) {
            if (text.equals("")) {
                this.setText("no title");
            } else {
                this.setText(text);
            }
        }

        private void initFavoritURLforAppStart(String starturl) {
            this.userFavoriteUrl = starturl;
        }

        void letEmptyButton() {
            this.userFavoriteUrl = "";
            this.setText("");
            this.setBrowserStrategy(new EmptyButtonStrategy());


        }
    }
}