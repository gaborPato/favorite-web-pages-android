package hu_hu.hobbijava.myfavoritewebpages.view

import android.content.Context
import android.graphics.Color
import android.widget.TextView
import android.widget.Toast

object CustomToast {

    @JvmStatic
    fun show (context: Context, message: String, color: Int){
        val t = android.widget.Toast.makeText(context, message, Toast.LENGTH_SHORT)
        t.view.setBackgroundColor(color)
        val text= t.view.findViewById<TextView>(android.R.id.message)
        text.textSize=21.7f
        text.setTextColor(Color.WHITE)
        t.show()
    }
}