package hu_hu.hobbijava.myfavoritewebpages.controler.Address;

import hu_hu.hobbijava.myfavoritewebpages.controler.exceptions.EmptyUrlException;
import hu_hu.hobbijava.myfavoritewebpages.controler.exceptions.InvalidUrlException;
import hu_hu.hobbijava.myfavoritewebpages.controler.tools.CheckTools;

public final class ButtonWebAddress extends AddressWeb {
    public ButtonWebAddress(String userQuery) throws EmptyUrlException, InvalidUrlException {
        super(userQuery);
        if (userQuery.length() < 1 || userQuery == null) {
            throw new EmptyUrlException();
        }
        userQuery = CheckTools.INSTANCE.clearAndMakeHTTPUrl(userQuery);
        if (CheckTools.INSTANCE.urlValidator(userQuery)) {
            url = userQuery;
        } else {
            throw new InvalidUrlException();
        }
    }
}
