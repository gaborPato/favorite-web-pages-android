package hu_hu.hobbijava.myfavoritewebpages.controler.exceptions;

import androidx.annotation.Nullable;

public final class EmptyUrlException extends Exception {
    @Nullable
    @Override
    public String getMessage() {
        return "Empty URL!!!!!";
    }
}
