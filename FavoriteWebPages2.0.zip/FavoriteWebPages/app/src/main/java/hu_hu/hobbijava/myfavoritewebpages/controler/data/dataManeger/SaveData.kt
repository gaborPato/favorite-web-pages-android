package hu_hu.hobbijava.myfavoritewebpages.controler.data.dataManeger

import android.content.Context
import android.content.SharedPreferences

import com.android_tanfolyam.myfavoritewebpages.R

object SaveData {

    private var preferences: SharedPreferences? = null


    fun buttonTextSave(context: Context, userButtonText: List<String>) {

        preferences = context.getSharedPreferences(context.getString(R.string.shared_button_name), Context.MODE_PRIVATE)


        for (i in userButtonText.indices) {

            preferences?.edit()?.putString(context.getString(R.string.shared_button_text) + i.toString(), userButtonText[i])?.commit()
        }


    }

    fun webSiteAddressTextSave(context: Context, userFavUrl: List<String>) {
        preferences = context.getSharedPreferences(context.getString(R.string.shared_web_url_name), Context.MODE_PRIVATE)

        for (i in userFavUrl.indices) {

            preferences?.edit()?.putString(context.getString(R.string.shared_web_url_text) + i.toString(), userFavUrl[i])?.commit()
        }


    }

    fun externalOpenStatusSave(context: Context, externalOpen: List<Boolean>) {
        preferences = context.getSharedPreferences(context.getString(R.string.shared_ext_open_name), Context.MODE_PRIVATE)

        for (i in externalOpen.indices) {
            preferences?.edit()?.putBoolean(context.getString(R.string.shared_ext_open_bool) + i.toString(), externalOpen[i])?.commit()
        }
    }
}

