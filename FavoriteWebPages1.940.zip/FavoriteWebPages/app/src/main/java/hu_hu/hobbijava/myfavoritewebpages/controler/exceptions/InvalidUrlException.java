package hu_hu.hobbijava.myfavoritewebpages.controler.exceptions;

import androidx.annotation.Nullable;

public final class InvalidUrlException extends Exception {

    @Nullable
    @Override
    public String getMessage() {

        return "Invalid URL!!!!!!";
    }
}
