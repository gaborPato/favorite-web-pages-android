package hu_hu.hobbijava.myfavoritewebpages.controler.data

import android.graphics.Color

object CustomToastColor {

    val errorNotifyColor= Color.rgb(201,0,7)
    val infoNotifyColor= Color.rgb(0,5,156)
    val okNotifyColor= Color.rgb(0,156,5)

}