package hu_hu.hobbijava.myfavoritewebpages.controler.Address;

public abstract class AddressWeb {

    protected String url;

    public String getUrl() {
        return url;
    }

    public AddressWeb(String userQuery) {


    }
}
