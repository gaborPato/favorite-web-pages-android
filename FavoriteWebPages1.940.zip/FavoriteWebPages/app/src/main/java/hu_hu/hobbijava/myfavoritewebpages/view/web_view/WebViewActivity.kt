package hu_hu.hobbijava.myfavoritewebpages.view.web_view

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.media.AudioManager
import android.media.AudioTrack
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.android_tanfolyam.myfavoritewebpages.R
import hu_hu.hobbijava.myfavoritewebpages.controler.Address.AddressWeb
import hu_hu.hobbijava.myfavoritewebpages.controler.Address.WVUserAddress
import hu_hu.hobbijava.myfavoritewebpages.controler.data.CustomToastColor
import hu_hu.hobbijava.myfavoritewebpages.controler.tools.CalculateTools
import hu_hu.hobbijava.myfavoritewebpages.controler.tools.ShareTool
import hu_hu.hobbijava.myfavoritewebpages.view.CustomToast
import hu_hu.hobbijava.myfavoritewebpages.view.MainActivity
import kotlinx.android.synthetic.main.activity_web_view.*


@Suppress("DEPRECATION")
class WebViewActivity : AppCompatActivity() {

    private lateinit var progressDialog: ProgressDialog
    private lateinit var searchViewArray: ArrayList<View>
    private lateinit var userSearchQuery: AddressWeb
    private var urlFlag: String =""
    private var bookMarkTitle = arrayOfNulls<String>(MainActivity.getAllowedBookMark().size)
    private var passURL:String=""
    private var counter= 1


    companion object {

        private val supportedRunMimeType = arrayListOf("application/pdf")


    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_view)
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        this.window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        initBookmarkTitle()


        val defaultDisplay = windowManager.defaultDisplay

        urlFlag= getString(R.string.normal_page_flag)
        passURL= getString(R.string.default_pass_url_data)

        if (intent != null){
        counter= intent.getIntExtra("counter",1)
            Log.i("counter",counter.toString())

            val getDataIntent = intent.getStringArrayExtra(getString(R.string.pass_url))
            if (getDataIntent != null){
                passURL = getDataIntent[0]
                urlFlag = getDataIntent[1]

            }


        }
        page_counter.setText(counter.toString())



        progressDialog = ProgressDialog(this)

        progressDialog.setCancelable(true)
        web_view.webViewClient = AppWVClient()
        web_view.webChromeClient = ChromeClient(progressDialog)

        web_view.settings.javaScriptEnabled = true
        web_view.settings.loadsImagesAutomatically = true

        web_view.settings.builtInZoomControls = true
        web_view.settings.javaScriptCanOpenWindowsAutomatically = true

        web_view.settings.domStorageEnabled = true
        web_view.settings.setAppCacheEnabled(true)
        web_view.settings.setSupportMultipleWindows(true)



        searchViewArray = arrayListOf<View>(search_button, search_editText, new_page_ico)
            web_view.loadUrl(passURL)

        if (CalculateTools.checkX_Size(defaultDisplay) > 719) {
            share_image_ico.visibility = View.VISIBLE
            share_image_ico.setOnClickListener(View.OnClickListener {
                ShareTool.shareUrl(this, web_view.url)
            })
        }

        copyButton.setOnClickListener(View.OnClickListener {






            val url: String = web_view.url
            val clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val checkLabel = java.util.Random().nextInt(9000000).toString()
            val urlText: ClipData = ClipData.newPlainText(checkLabel, url)
            clipboardManager.setPrimaryClip(urlText)
            if (clipboardManager.primaryClip?.description?.label?.equals(checkLabel) as Boolean) {

                CustomToast.show(this," Actual url copied to clipboard",CustomToastColor.okNotifyColor)


                try {
                    val notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    val r = RingtoneManager.getRingtone(applicationContext, notification)
                    r.play()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {

                CustomToast.show(this,"Copy error",CustomToastColor.errorNotifyColor)
            }

        })



        up_down_ico.setOnClickListener(View.OnClickListener {
            searchViewArray.forEach { v ->
                if (v.visibility == View.GONE) {
                    v.visibility = View.VISIBLE
                    up_down_ico.setImageResource(R.drawable.up_ico)
                } else {
                    v.visibility = View.GONE
                    up_down_ico.setImageResource(R.drawable.down_ico)

                }
            }
        })
        search_button.setOnClickListener(View.OnClickListener {

            var query = search_editText.text.toString()
            if (query.length > 0) {

                userSearchQuery = WVUserAddress(query)
                query = userSearchQuery.url

                web_view.loadUrl(query)
                val imm = this.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_NOT_ALWAYS)
            }
            search_editText.setText("")
        })

        new_page_ico.setOnClickListener(View.OnClickListener {

            newPageAction(search_editText.text.toString())

        })

        bookmark_ico_btn.setOnClickListener(View.OnClickListener {

            BookmarkAlertDialog(this)

        })

        forward_imageButton.setOnClickListener(View.OnClickListener {
            if (web_view.canGoForward()) {
                web_view.goForward()
            }
        })
        back_imageButton.setOnClickListener(View.OnClickListener {
            can_backPageAction()

        })

        refresh_button.setOnClickListener({
            val actualUrl = web_view.url
            web_view.loadUrl(actualUrl)
        })
        close_btn_ico.setOnClickListener({

            closeWebViewProtocol()

        })
        web_view.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->

            Log.i("downloadMime", mimetype)
            if (supportedRunMimeType.contains(mimetype)) {
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(url)
                startActivity(i)
            }

        })

    }

    private fun initBookmarkTitle() {

        MainActivity.getAllowedBookMark().forEachIndexed { index, allowedBookMark ->
            bookMarkTitle[index] = allowedBookMark.title
        }
    }

    protected fun newPageAction(userQuery: String) {

        counter++
        var query = userQuery
        val i = Intent(this@WebViewActivity, WebViewActivity::class.java)
        i.putExtra("counter",counter)
        if (query.length < 1) {
            i.putExtra(getString(R.string.pass_url), arrayOf(getString(R.string.blank_page_url), getString(R.string.new_page_flag)))


        } else {
            userSearchQuery = WVUserAddress(query)
            query = userSearchQuery.url
            i.putExtra(getString(R.string.pass_url), arrayOf(query, getString(R.string.new_page_flag)))
        }
        web_view.context.startActivity(i)
    }

    private fun closeWebViewProtocol() {
        if (urlFlag.equals(getString(R.string.new_page_flag))) {
            super.onBackPressed()
        } else {
            val dialog = ExitAlertDialog(this)
            dialog.setOnDismissListener {
                if (ExitAlertDialog.getExit()) {
                    super.onBackPressed()
                }
            }
            dialog.show()
        }


    }

    private fun can_backPageAction(): Boolean {
        if (web_view.canGoBack()) {
            web_view.goBack()
            return true
        }
        return false
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val orientation = newConfig.orientation
        when (orientation) {
            Configuration.ORIENTATION_LANDSCAPE ->
                web_view_controller_layout.visibility = View.GONE
            Configuration.ORIENTATION_PORTRAIT ->
                web_view_controller_layout.visibility = View.VISIBLE
        }
    }


    override fun onBackPressed() {

        if (!can_backPageAction()) {
            closeWebViewProtocol()
        }

    }

    inner class ChromeClient(pd: ProgressDialog) : WebChromeClient() {

        private var pd: ProgressDialog = pd

        override fun onProgressChanged(view: WebView?, newProgress: Int) {


            if (newProgress < 100) {
                pd.setMessage("load data: $newProgress %")
                pd.show()
            }
            if (newProgress == 100) {
                pd.dismiss()
            }


        }

        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {

            val result = view?.hitTestResult
            val data = result?.extra
            if (data != null) {
                newPageAction(data)
                return true
            }
            return false
        }

    }


    inner class AppWVClient : WebViewClient() {


        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
            view?.loadUrl(url)

            return true
        }


    }

    inner class BookmarkAlertDialog(context: Context?) : AlertDialog.Builder(context) {

        init {

            this.setTitle("Bookmarks :")
            this.setIcon(R.drawable.bookmark_colorful)

            this.setItems(bookMarkTitle,  { dialog, which ->

                MainActivity.getAllowedBookMark().forEachIndexed { index, item ->

                    if(index==which){
                        if (item.externalOpen){

                            openExternalBookmark(item.url)
                        }else{
                            web_view.loadUrl(item.url)
                        }

                        return@forEachIndexed
                    }
                }


            })
            this.create().show()

        }
        private fun  openExternalBookmark(url: String) {
            intent= Intent(Intent.ACTION_VIEW)
            intent.data= Uri.parse(url)
            startActivity(intent)
        }
    }
}








