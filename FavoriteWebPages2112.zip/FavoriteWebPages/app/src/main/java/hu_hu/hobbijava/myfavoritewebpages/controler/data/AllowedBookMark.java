package hu_hu.hobbijava.myfavoritewebpages.controler.data;

import androidx.annotation.NonNull;

public  class AllowedBookMark {

    private  String title;
    private  String url;
    private boolean externalOpen;

    public AllowedBookMark(String title, String url,boolean externalOpen) {
        this.title = title;
        this.url = url;
        this.externalOpen = externalOpen;
    }

    public String getTitle() {
        return title;
    }



    public String getUrl() {
        return url;
    }

    public boolean getExternalOpen() {
        return externalOpen;
    }


    @NonNull
    @Override
    public String toString() {
        return "title : "+ title +" | url: "+url + " | internalOpen : " + externalOpen;
    }
}
