package hu_hu.hobbijava.myfavoritewebpages.controler.tools

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkInfo
import android.os.Build
import org.apache.commons.validator.routines.UrlValidator
import java.lang.NullPointerException

object CheckTools {


    fun checkNetwork(context: Context): Boolean {

        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager




         if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
             val activeNetwork = connectivityManager.activeNetwork
            if (activeNetwork == null) {
                return false
            }
            val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)

            return ( networkCapabilities != null && (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)))


        } else {
             val wifiNetInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI)
             val cellNetInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE)

             if (wifiNetInfo == null || cellNetInfo == null){
                 return false

             }
             return   (wifiNetInfo.state == NetworkInfo.State.CONNECTED
                     || cellNetInfo.state == NetworkInfo.State.CONNECTED)





        }
    }


    fun clearAndMakeHTTPUrl(queryUrl: String): String {
        var url: String = queryUrl.toLowerCase()
        if (url.startsWith("www.")) {
            url = url.substringAfter(".")
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://${url}"
        }
        return url
    }

    fun urlValidator(user_query: String): Boolean {

        var query = user_query



        println("query: $query")

        val scheme = arrayOf("http", "https")
        val urlValidator = UrlValidator(scheme)
        val valid: Boolean = urlValidator.isValid(query)
        return valid

    }
}