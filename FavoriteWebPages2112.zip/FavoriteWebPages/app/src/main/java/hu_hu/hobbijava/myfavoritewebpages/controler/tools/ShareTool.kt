package hu_hu.hobbijava.myfavoritewebpages.controler.tools

import android.content.Context
import android.content.Intent

object ShareTool {
    fun shareUrl(context: Context, url: String) {


        try {
            val shIntent = Intent(Intent.ACTION_SEND)
            shIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            shIntent.setType("*/*")
            shIntent.putExtra(Intent.EXTRA_TEXT, url)
            val chooserIntent = Intent.createChooser(shIntent, "Send Actual Address")
            chooserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooserIntent)
        } catch (E_: Exception) {
            println("ShareException : ${E_.message}")
        }

    }

}