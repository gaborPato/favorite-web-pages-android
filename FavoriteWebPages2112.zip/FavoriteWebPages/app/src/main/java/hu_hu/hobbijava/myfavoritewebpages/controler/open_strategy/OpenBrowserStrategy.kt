package hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy

interface OpenBrowserStrategy {

    abstract fun getBackgrResource(): Int
    fun getExternalOpenBrowser(): Boolean
}