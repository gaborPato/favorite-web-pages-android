package hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy

import com.android_tanfolyam.myfavoritewebpages.R

class EmptyButtonStrategy : hu_hu.hobbijava.myfavoritewebpages.controler.open_strategy.OpenBrowserStrategy {
    override fun getExternalOpenBrowser(): Boolean {
        return true;
    }

    override fun getBackgrResource(): Int {
        return R.drawable.empty_button_gradient_resize
    }


}
